			jsEngine.modules.interactions = 5;
			jsEngine.modules.physics.e = 0.5;

			function drawVector (s,v) {
				html5.context.lineWidth = 2.0;
				html5.context.beginPath ();
				html5.context.moveTo (s[0],s[1]);
				html5.context.lineTo (s[0]+v[0],s[1]+v[1]);
				html5.context.closePath();
				html5.context.stroke();
			}

			function drawDot (s,v) {
				html5.context.lineWidth = 2.0;
				html5.context.beginPath ();
				html5.context.arc (s[0]+v[0],s[1]+v[1],2,0,Math.PI*2,false);
				html5.context.closePath();
				html5.context.stroke();
			}

			function drawQuad (q,n) {
				var v;
				var s = [0,0];
				for (v=0;v<q.length;v++) {
					html5.context.strokeStyle = "black";
					s = jsEngine.modules.math.sub(q[(v+1)%q.length],q[v]);
					drawVector (q[v],s);
					html5.context.strokeStyle = "red";
					drawVector (jsEngine.modules.math.add(q[v],jsEngine.modules.math.mul(s,0.5)),jsEngine.modules.math.mul(n[v],10));
				}
			}

			function getNormals (q) {
				var vMath = jsEngine.modules.math;

				var v;
				var s = [0,0];
				var n = [];
				var k;
				for (v=0;v<q.length;v++) {
					s = vMath.sub(q[(v+1)%q.length],q[v]);
					k = [s[1],-s[0]];
					n.push (vMath.normalize(k));
				}
				return n;
			}

			var obj1 = new jsEngine.modules.physics.DynamicObject ();
			var obj2 = new jsEngine.modules.physics.StaticObject ();
			var obj3 = new jsEngine.modules.physics.StaticObject ();
			var obj4 = new jsEngine.modules.physics.StaticObject ();

			obj1.p = [320,0];
			obj1.a = [0,0.1];
			obj1.hull = [[0,0],[100,0],[100,100],[0,100]];

			obj2.p = [0,450];
			obj2.hull = [[0,-800],[500,0],[500,120],[0,400]];

			obj3.p = [450,350];
			obj3.hull = [[0,0],[100,0],[100,100],[0,100]];

			obj4.p = [780,0];
			obj4.hull = [[0,0],[200,0],[100,800],[0,100]];

			jsEngine.modules.physics.s_objects.push (obj3);
			jsEngine.modules.physics.s_objects.push (obj2);
			jsEngine.modules.physics.d_objects.push (obj1);
			jsEngine.modules.physics.s_objects.push (obj4);
			
			function update () {
				html5.context.fillStyle = "white";
				html5.context.fillRect (0,0,html5.canvas.width,html5.canvas.height);

				var i;
				for (i in jsEngine.modules.physics.d_objects) {
					var hull = jsEngine.modules.physics.d_objects[i].hull;
					var p = jsEngine.modules.physics.d_objects[i].p;

					html5.context.save ();
						html5.context.translate (p[0],p[1]);
						drawQuad (hull,getNormals(hull));
					html5.context.restore();
				}
				for (i in jsEngine.modules.physics.s_objects) {
					var hull = jsEngine.modules.physics.s_objects[i].hull;
					var p = jsEngine.modules.physics.s_objects[i].p;

					html5.context.save ();
						html5.context.translate (p[0],p[1]);
						drawQuad (hull,getNormals(hull));
					html5.context.restore();
				}

				if (html5.keyboard[html5.keyLeft])
					obj1.v[0] -= 1;
				if (html5.keyboard[html5.keyRight])
					obj1.v[0] += 1;
				if (html5.keyboard[html5.keyDown])
					obj1.v[1] += 1;
				if (html5.keyboard[html5.keyUp])
					obj1.v[1] -= 1;

				jsEngine.modules.physics.step();
			}

			i = setInterval(update,32);

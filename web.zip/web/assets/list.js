/*
	Copyright (C) 2012,2013 by Calango Rei Games, wich is:
	Felipe Tavares, Brenno Arruda, Vinicius Abdias, Mateus Medeiros and Giovanna Gorgônio
*/

jsEngine.assetList = [
	new JSAsset("assets/animation/player/",AssetAnimation,{framecount: 6}),
	new JSAsset("assets/animation/assassin/",AssetAnimation,{framecount: 6}),
	new JSAsset("assets/animation/salto/",AssetAnimation,{framecount: 8}),
	new JSAsset("assets/images/bazinga.logo.png",AssetImage,{}),
];

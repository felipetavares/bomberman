/*
	Copyright (C) 2012,2013 by Calango Rei Games, wich is:
	Felipe Tavares, Brenno Arruda, Vinicius Abdias, Mateus Medeiros and Giovanna Gorgônio
*/

var scnLogo = {
	"scene": function () {
		this.backgroundColor = "white";
		this.textColor = "black";
	},

	"renderer": function () {
		this.scene = null;
		this.s = 4;
		this.a = 4;

		this.startt = jsEngine.pt;

		this.render = function () {
			jsEngine.smoothImage();

			html5.context.fillStyle = this.scene.backgroundColor;
			html5.context.fillRect (0,0,html5.canvas.width,html5.canvas.height);

			var img = html5.image("assets/images/bazinga.logo.png");

			if (this.a*4*img.height > html5.canvas.height/2) {
				this.a -= jsEngine.dt;
				this.s = this.a;
			} else {
				var time = jsEngine.pt-this.startt;
				if (time > 5) {// Cinco segundos 
					var nextRenderer = new scnIntro.renderer();
					nextRenderer.scene = new scnIntro.scene();
					jsEngine.modules.render.renderer = nextRenderer;
				}
			}

			html5.context.save();
				html5.context.translate (html5.canvas.width/2,html5.canvas.height/2);
				html5.context.scale (4*this.s,4*this.s);

				html5.context.drawImage (img,
										 -img.width/2,-img.height/2);
			html5.context.restore();
		}
	}
}

var scnIntro = {
	"scene": function () {
		this.backgroundColor = "black";
		this.textColor = "yellow";
		this.textTime = 5;
		this.texts = [
			"Felipe Tavares",
			"Gabriel Araújo",
			"Camila Medeiros",
			"Cíntia Alves",
			"Ana Cecília",
			"apresentam",
			"Bomberman 2D",
			"a Rayslla Almeida game",
		];
	},

	"renderer": function () {
		this.scene = null;
		this.fontSize = 60;

		this.startTime = jsEngine.pt;

		this.calcFontSize = function (text, desired) {
			html5.context.font = Math.floor(this.fontSize)+"px sans-serif";
			// Tamanho com a fonte atual
			var current = html5.context.measureText(text).width;

			// Calcula o tamanho para a font que queremos (regra de 3)
			this.fontSize = Math.floor(this.fontSize)*desired/current;
		}

		this.renderText = function (text) {
			var time = (jsEngine.pt-this.startTime);

			this.calcFontSize(text,html5.canvas.width/2);

			html5.context.textAlign = "center";
			html5.context.textBaseline = "middle";
			html5.context.font = this.fontSize+"px sans-serif";
			html5.context.fillText (text, html5.canvas.width/2+Math.cos(time)*html5.canvas.width/4,
										  html5.canvas.height/2+Math.sin(time)*html5.canvas.height/4);
		}

		this.render = function () {
			html5.context.fillStyle = this.scene.backgroundColor;
			html5.context.fillRect (0,0,html5.canvas.width,html5.canvas.height);

			var time = jsEngine.pt-this.startTime;
			var text = this.scene.texts[parseInt(time/this.scene.textTime)];
			time = time%this.scene.textTime/this.scene.textTime*Math.PI*2;

			html5.context.fillStyle = "rgba(255,255,0,"+(-Math.cos(time))+")";
			this.renderText (text);
		}
	}
}

function scnMenu () {
	var panel = new UIPanel();
	var dialog = new UIListView("Menu");
	var save = new UIListView("Save Game");
	var load = new UIListView("Load Game");

	panel.open();
	panel.addView (dialog);
	panel.addView (save);
	panel.addView (load);

	dialog.constructor = function () {
		this.list = [
			{
				content: "Save",
				onActivate: function () {this.panel.switchTo(1)},
				onSelect: null
			},
			{
				content: "Load",
				onActivate: function () {this.panel.switchTo(2)},
				onSelect: null
			},
			{
				content: "Cancel",
				onActivate: function () {this.panel.hide()},
				onSelect: null
			}
		];
	}

	load.constructor = function () {
		this.list = [
			{
				content: "↵",
				onActivate: function () {this.panel.switchTo(0)},
				onSelect: null
			}
		];
	}

	save.constructor = function () {
		this.list = [
			{
				content: "↵",
				onActivate: function () {this.panel.switchTo(0)},
				onSelect: null
			}
		];
	}

	jsEngine.modules.ui.show (panel);

			var anim;

			if (this.x < 100)
				anim = jsEngine.modules.assets.getAnimationID("assets/animation/assassin/");
			else
				anim = jsEngine.modules.assets.getAnimationID("assets/animation/salto/");

			var img = jsEngine.modules.animation.getAnimationImage(anim);

			html5.context.drawImage (img,
									 this.x+html5.canvas.width/2-img.width/2,html5.canvas.height/2-img.height/2);
}

function drawVector (s,v) {
	html5.context.lineWidth = 2.0;
	html5.context.beginPath ();
	html5.context.moveTo (s[0],s[1]);
	html5.context.lineTo (s[0]+v[0],s[1]+v[1]);
	html5.context.closePath();
	html5.context.stroke();
}

function drawDot (s,v) {
	html5.context.lineWidth = 2.0;
	html5.context.beginPath ();
	html5.context.arc (s[0]+v[0],s[1]+v[1],2,0,Math.PI*2,false);
	html5.context.closePath();
	html5.context.stroke();
}

function drawQuad (q,n) {
	var v;
	var s = [0,0];
	for (v=0;v<q.length;v++) {
		html5.context.strokeStyle = "black";
		s = jsEngine.modules.math.sub(q[(v+1)%q.length],q[v]);
		drawVector (q[v],s);
		//html5.context.strokeStyle = "red";
		//drawVector (jsEngine.modules.math.add(q[v],jsEngine.modules.math.mul(s,0.5)),jsEngine.modules.math.mul(n[v],10));
	}
}

function getNormals (q) {
	var vMath = jsEngine.modules.math;

	var v;
	var s = [0,0];
	var n = [];
	var k;
	for (v=0;v<q.length;v++) {
		s = vMath.sub(q[(v+1)%q.length],q[v]);
		k = [s[1],-s[0]];
		n.push (vMath.normalize(k));
	}
	return n;
}

var scnEditor = {
	"scene": function () {
		this.backgroundColor = "green";
		this.textColor = "lightgreen";
		this.layers = [[]];
	},

	"renderer": function () {
		this.scene = null;

		this.misalign = [0,0];
		this.click = false;
		this.selected = null;
		this.editselected = null;
		this.editpt = null;

		this.render = function () {
			html5.context.fillStyle = this.scene.backgroundColor;
			html5.context.clearRect (0,0,html5.canvas.width,html5.canvas.height);
			
			var o;
			for (o in this.scene.layers[0]) {
				var object = this.scene.layers[0][o];
				html5.context.save();
				html5.context.translate (object.physics.p[0],object.physics.p[1]);
				html5.context.rotate (object.physics.w);
				drawQuad (object.physics.hull,getNormals(object.physics.hull));
				html5.context.restore();

				if (this.editselected == o || this.editselected==null) {
					var hull = object.physics.hull;
					this.editselected = o;
				} else {
					this.editselected = null;
				}

				if (html5.keyboard[html5.keyEnter]) {
					html5.keyboard[html5.keyEnter] = false;

					editorRenderer.scene.layers[0].push ({
						physics: new jsEngine.modules.physics.StaticObject(), 
					});
					var nobj = editorRenderer.scene.layers[0].length-1;
					editorRenderer.scene.layers[0][nobj].physics.p = [200,200];
					//editorRenderer.scene.layers[0][nobj].physics.hull = jsEngine.modules.math.mcopy(Poly);
				
					jsEngine.modules.physics.s_objects.push(editorRenderer.scene.layers[0][nobj].physics);
				}

				if (html5.mouseButton) {
					var mousePoly = [];
					var pointPoly = [[0,-2.5],[2.5,2.5],[-2.5,2.5]];

					mousePoly[2] = [html5.mousePos[0],html5.mousePos[1]];
					mousePoly[1] = [html5.mousePos[0]+1,html5.mousePos[1]];
					mousePoly[0] = [html5.mousePos[0],html5.mousePos[1]+1];					
		
					var d = jsEngine.modules.collision.SAT(jsEngine.modules.math.madd(object.physics.hull,object.physics.p),
														   mousePoly);


					var p;
					var cont = false;
					for (p in object.physics.hull) {
						var poly = jsEngine.modules.math.madd (pointPoly, object.physics.hull[p]);
						poly = jsEngine.modules.math.madd(poly,object.physics.p);

						var c = jsEngine.modules.collision.SAT(poly,
													   mousePoly);
					
						if (c || (this.editpt == p && this.selected == o)) {
							this.editpt = p;
							this.selected = o;
							object.physics.hull[p][0] = html5.mousePos[0]-object.physics.p[0];
							object.physics.hull[p][1] = html5.mousePos[1]-object.physics.p[1];
							cont = true;
						}
					}

					if (cont) {
						this.click = false;
						continue;
					}

					if (d && this.selected == null)
						this.selected = o;

					if (this.selected == o) {
						if (!this.click) {
							this.misalign = jsEngine.modules.math.sub (object.physics.p,
																	   html5.mousePos);
							this.click = true;
						}
						object.physics.p[0] = html5.mousePos[0]+this.misalign[0];
						object.physics.p[1] = html5.mousePos[1]+this.misalign[1];
					}
				} else {
					this.click = false;
					this.selected = null;
					this.editpt = null;
				}
			}
		
			if (html5.keyboard[html5.keyDown]) {
				this.saveMap();
				html5.keyboard[html5.keyDown] = false;
			}
			if (html5.keyboard[html5.keyUp]) {
				this.loadMap();
				html5.keyboard[html5.keyUp] = false;
			}
		}

		this.saveMap = function () {
			localStorage.map = JSON.stringify(this.scene);
		}

		this.loadMap = function () {
			this.scene = JSON.parse(localStorage.map);
		}
	}
}

// This is the main scene,
// it is very complex and represent all objects within the game
var scnGame = {
	"scene": function () {
		this.backgroundColor = "black";
		this.layers = []; // Each layer is a vector of objects;
		/*
			Each object needs the following MANDATORY properties:

			* a draw method
		*/
	},

	"renderer": function () {
		this.scene = null;

		this.render = function () {

		}
	}
}

function GameRender () {
	this.info = JSInfo ("Matrix",
						1.0,
						"Game Render",
						"Render the game, based in objects");
	this.depends = [];

	this.renderer = null;

	this.render = function () {
		this.renderer.render();
	}
}
